import { useState } from 'react'
// import reactLogo from './assets/react.svg'
// import viteLogo from '/vite.svg'
import './App.css'
// import { Quiz } from './Components/Quiz'
// import { Home } from './Components/Home'
import QuizApp from './Components/QuizApp'

function App () {
     return(
     
    <QuizApp/>)
}
export default App;